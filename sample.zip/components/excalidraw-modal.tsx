"use client"

import React, { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { X, Save } from "lucide-react"
import dynamic from "next/dynamic"
import "@excalidraw/excalidraw/index.css"

// Import Excalidraw dynamically with no SSR
const Excalidraw = dynamic(
  () => import("@excalidraw/excalidraw").then((mod) => ({ default: mod.Excalidraw })),
  { 
    ssr: false,
    loading: () => (
      <div className="w-full h-full flex items-center justify-center bg-slate-50">
        <div className="text-slate-400">Loading drawing canvas...</div>
      </div>
    )
  }
)

interface ExcalidrawModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (drawingData: string) => void
  initialData?: string
}

const ExcalidrawModal = React.memo<ExcalidrawModalProps>(({ 
  isOpen, 
  onClose, 
  onSave, 
  initialData 
}) => {
  const [excalidrawAPI, setExcalidrawAPI] = useState<any>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setIsLoaded(true)
    }
  }, [isOpen])

  if (!isOpen) return null

  const handleSave = async () => {
    if (excalidrawAPI) {
      try {
        const elements = excalidrawAPI.getSceneElements()
        const appState = excalidrawAPI.getAppState()

        console.log('Saving drawing with elements:', elements.length, 'elements')

        const drawingData = JSON.stringify({
          elements: elements,
          appState: {
            viewBackgroundColor: appState.viewBackgroundColor || "#ffffff",
            gridSize: appState.gridSize || null,
            scrollX: appState.scrollX || 0,
            scrollY: appState.scrollY || 0,
            zoom: appState.zoom || { value: 1 }
          }
        })

        console.log('Drawing data to save:', drawingData.substring(0, 200) + '...')
        onSave(drawingData)
        onClose()
      } catch (error) {
        console.error('Error saving drawing:', error)
        // Save empty drawing data if there's an error
        onSave(JSON.stringify({ elements: [], appState: {} }))
        onClose()
      }
    } else {
      console.warn('Excalidraw API not available, saving empty drawing')
      onSave(JSON.stringify({ elements: [], appState: {} }))
      onClose()
    }
  }

  const parseInitialData = () => {
    if (!initialData) return undefined
    
    try {
      const parsed = JSON.parse(initialData)
      return {
        elements: parsed.elements || [],
        appState: parsed.appState || {}
      }
    } catch (error) {
      console.error("Error parsing initial data:", error)
      return undefined
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[60]"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{
          duration: 0.2,
          type: "spring",
          stiffness: 400,
          damping: 30,
        }}
        className="bg-white rounded-3xl w-full max-w-7xl h-[90vh] overflow-hidden relative shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-white relative z-10 h-16">
          <h2 className="text-xl font-medium text-slate-800">Drawing Canvas</h2>
          <div className="flex items-center space-x-2">
            <Button
              onClick={handleSave}
              className="bg-orange-600 hover:bg-orange-700 text-white rounded-xl px-4 py-2 text-sm"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Drawing
            </Button>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-orange-600"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>
        
        {/* Excalidraw Container */}
        <div 
          className="w-full bg-white" 
          style={{ height: "calc(90vh - 64px)" }}
        >
          {isLoaded && (
            <Excalidraw
              excalidrawAPI={(api) => {
                console.log('Excalidraw API loaded:', api)
                setExcalidrawAPI(api)
              }}
              initialData={parseInitialData()}
              UIOptions={{
                canvasActions: {
                  saveToActiveFile: false,
                  loadScene: false,
                  export: false,
                  saveAsImage: false,
                },
                tools: {
                  image: false,
                },
              }}
            />
          )}
        </div>
      </motion.div>
    </motion.div>
  )
})

ExcalidrawModal.displayName = "ExcalidrawModal"

export default ExcalidrawModal