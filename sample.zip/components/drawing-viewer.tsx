"use client"

import React, { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { X, Edit3, Expand, PenTool } from "lucide-react"
import dynamic from "next/dynamic"
import "@excalidraw/excalidraw/index.css"

const Excalidraw = dynamic(
  async () => (await import("@excalidraw/excalidraw")).Excalidraw,
  { ssr: false }
)

interface DrawingViewerProps {
  drawingData: string
  onEdit?: () => void
  onDelete?: () => void
  isPreview?: boolean
}

const DrawingViewer = React.memo<DrawingViewerProps>(({ 
  drawingData, 
  onEdit, 
  onDelete, 
  isPreview = false 
}) => {
  const [isExpanded, setIsExpanded] = useState(false)

  try {
    const parsedData = JSON.parse(drawingData)
    
    // Check if there are actually elements to display
    const hasElements = parsedData?.elements && parsedData.elements.length > 0
    
    if (isPreview) {
      return (
        <div className="my-4 p-4 border border-slate-200 rounded-2xl bg-slate-50/50 hover:bg-slate-100/70 transition-all duration-200 cursor-pointer group" onClick={onEdit}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <PenTool className="w-4 h-4 text-slate-500" />
              <span className="text-sm text-slate-600 font-medium">Drawing</span>
            </div>
            <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
              {onEdit && (
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    onEdit()
                  }}
                  variant="ghost"
                  size="sm"
                  className="text-slate-400 hover:text-orange-600 p-1 h-7 w-7"
                >
                  <Edit3 className="w-3 h-3" />
                </Button>
              )}
              {onDelete && (
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    onDelete()
                  }}
                  variant="ghost"
                  size="sm"
                  className="text-slate-400 hover:text-red-600 p-1 h-7 w-7"
                >
                  <X className="w-3 h-3" />
                </Button>
              )}
            </div>
          </div>
          
          {hasElements ? (
            <div className="h-32 rounded-lg overflow-hidden border border-slate-200 bg-white">
              <Excalidraw
                initialData={parsedData}
                viewModeEnabled={true}
                UIOptions={{
                  canvasActions: {
                    saveToActiveFile: false,
                    loadScene: false,
                    export: false,
                    saveAsImage: false,
                  },
                  tools: {
                    image: false,
                  },
                }}
              />
            </div>
          ) : (
            <div className="h-32 rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center bg-white">
              <div className="text-center text-slate-400">
                <PenTool className="w-6 h-6 mx-auto mb-2" />
                <p className="text-sm">Empty drawing</p>
              </div>
            </div>
          )}
          
          <div className="flex items-center justify-center mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
            <div className="flex items-center space-x-2 text-xs text-slate-500 bg-white/80 px-3 py-1 rounded-full border border-slate-200">
              <Edit3 className="w-3 h-3" />
              <span>Click to edit</span>
            </div>
          </div>
        </div>
      )
    }

    if (isExpanded) {
      return (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="my-4 border border-slate-200 rounded-2xl overflow-hidden shadow-lg"
        >
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-slate-100 border-b border-slate-200">
            <div className="flex items-center space-x-2">
              <PenTool className="w-4 h-4 text-slate-600" />
              <span className="text-sm font-medium text-slate-700">Drawing - Full View</span>
            </div>
            <div className="flex items-center space-x-2">
              {onEdit && (
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    onEdit()
                  }}
                  variant="ghost"
                  size="sm"
                  className="text-slate-400 hover:text-orange-600"
                >
                  <Edit3 className="w-4 h-4" />
                </Button>
              )}
              <Button
                onClick={() => setIsExpanded(false)}
                variant="ghost"
                size="sm"
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div style={{ height: "500px" }} className="bg-white">
            {hasElements ? (
              <Excalidraw
                initialData={parsedData}
                viewModeEnabled={true}
              />
            ) : (
              <div className="h-full flex items-center justify-center bg-slate-50">
                <div className="text-center text-slate-400">
                  <PenTool className="w-12 h-12 mx-auto mb-4" />
                  <p className="text-lg">No drawing content</p>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )
    }

    // Mini preview canvas - view only
    return (
      <div className="my-4 border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-200">
        <div className="flex items-center justify-between p-3 bg-gradient-to-r from-slate-50 to-slate-100 border-b border-slate-200">
          <div className="flex items-center space-x-2">
            <PenTool className="w-4 h-4 text-slate-600" />
            <span className="text-sm font-medium text-slate-700">Drawing</span>
          </div>
          <div className="flex items-center space-x-2">
            {onEdit && (
              <Button
                onClick={(e) => {
                  e.stopPropagation()
                  onEdit()
                }}
                variant="ghost"
                size="sm"
                className="text-slate-400 hover:text-orange-600"
              >
                <Edit3 className="w-4 h-4" />
              </Button>
            )}
            <Button
              onClick={(e) => {
                e.stopPropagation()
                setIsExpanded(true)
              }}
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-slate-600"
            >
              <Expand className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <div
          style={{ height: "250px" }}
          className="cursor-pointer hover:bg-slate-50/50 transition-colors relative overflow-hidden bg-white"
          onClick={(e) => {
            e.stopPropagation()
            onEdit?.()
          }}
        >
          {hasElements ? (
            <>
              <div className="w-full h-full">
                <Excalidraw
                  initialData={parsedData}
                  viewModeEnabled={true}
                  UIOptions={{
                    canvasActions: {
                      saveToActiveFile: false,
                      loadScene: false,
                      export: false,
                      saveAsImage: false,
                    },
                    tools: {
                      image: false,
                    },
                  }}
                />
              </div>
              {/* Overlay to indicate it's clickable for editing */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black/5 backdrop-blur-[1px]">
                <div className="bg-white/95 rounded-xl px-4 py-2 shadow-lg border border-slate-200">
                  <div className="flex items-center space-x-2 text-sm text-slate-600">
                    <Edit3 className="w-4 h-4" />
                    <span>Click to edit</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="h-full flex items-center justify-center bg-slate-50">
              <div className="text-center text-slate-400 p-8">
                <PenTool className="w-8 h-8 mx-auto mb-3" />
                <p className="text-sm">Empty drawing - Click to add content</p>
                <div className="mt-3 flex items-center justify-center space-x-2 text-xs text-slate-500 bg-white/80 px-3 py-1 rounded-full border border-slate-200">
                  <Edit3 className="w-3 h-3" />
                  <span>Click to edit</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  } catch (error) {
    console.error("Error parsing drawing data:", error)
    return (
      <div className="my-4 p-4 border border-red-200 rounded-2xl bg-red-50/50">
        <div className="flex items-center space-x-2 text-red-600">
          <X className="w-4 h-4" />
          <div>
            <span className="text-sm font-medium">Invalid drawing data</span>
            <p className="text-xs text-red-500 mt-1">Unable to parse drawing content</p>
          </div>
        </div>
        {onEdit && (
          <div className="mt-3">
            <Button
              onClick={onEdit}
              variant="ghost"
              size="sm"
              className="text-red-600 hover:text-red-700 text-xs"
            >
              <Edit3 className="w-3 h-3 mr-1" />
              Try to edit anyway
            </Button>
          </div>
        )}
      </div>
    )
  }
})

DrawingViewer.displayName = "DrawingViewer"

export default DrawingViewer