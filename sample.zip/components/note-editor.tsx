"use client"

import React, { useRef, useMemo, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { X, PenTool } from "lucide-react"
import SlashMenu from "./slash-menu"
import DrawingViewer from "./drawing-viewer"
import ExcalidrawModal from "./excalidraw-modal"
import { parseMarkdown } from "../lib/markdown-parser"

interface Note {
  id?: number
  title: string
  content: string
  createdAt?: Date
}

interface SlashCommand {
  id: string
  label: string
  description?: string
  icon?: React.ReactNode | string
  insert?: string
}

interface ImprovedNoteEditorProps {
  isOpen: boolean
  editingNote?: Note | null
  newNote: Note
  showSlashMenu: boolean
  selectedCommandIndex: number
  slashCommands: SlashCommand[]
  previewContent?: string
  onClose: () => void
  onSave: () => void
  onTitleChange: (title: string) => void
  onContentChange: (event: { target: { value: string } }) => void
  onCommandSelect: (command: SlashCommand) => void
  onDrawingAdd?: (drawingData: string) => void
  onDrawingUpdate?: (oldData: string, newData: string) => void
  onDrawingDelete?: (drawingData: string) => void
}

const ImprovedNoteEditor = React.memo<ImprovedNoteEditorProps>(({
  isOpen,
  editingNote,
  newNote,
  showSlashMenu,
  selectedCommandIndex,
  slashCommands,
  previewContent,
  onClose,
  onSave,
  onTitleChange,
  onContentChange,
  onCommandSelect,
  onDrawingAdd,
  onDrawingUpdate,
  onDrawingDelete,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const [showDrawingModal, setShowDrawingModal] = useState(false)
  const [editingDrawingIndex, setEditingDrawingIndex] = useState<number | null>(null)
  
  // Split content into text and drawings
  const { textContent, drawings } = useMemo(() => {
    if (!newNote.content) {
      return { textContent: '', drawings: [] }
    }
    
    const drawingRegex = /```drawing\n([\s\S]*?)\n```/g
    const drawings: string[] = []
    let match
    
    // Extract all drawings
    while ((match = drawingRegex.exec(newNote.content)) !== null) {
      drawings.push(match[1])
    }
    
    // Get text content without drawing blocks
    const textContent = newNote.content.replace(drawingRegex, '').trim()
    
    return { textContent, drawings }
  }, [newNote.content])

  const isDisabled = useMemo(() => {
    return !newNote.title.trim() || (!textContent.trim() && drawings.length === 0)
  }, [newNote.title, textContent, drawings.length])

  // Fixed text content change handler
  const handleTextContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newTextContent = e.target.value
    
    // Reconstruct full content by combining text and existing drawings
    let fullContent = newTextContent
    
    // Append existing drawings at the end, preserving their order
    if (drawings.length > 0) {
      drawings.forEach((drawing) => {
        fullContent += `\n\n\`\`\`drawing\n${drawing}\n\`\`\``
      })
    }
    
    // Call parent handler with the reconstructed content
    onContentChange({
      target: { value: fullContent }
    })
  }

  // Enhanced slash command handler
  const handleSlashCommandSelect = (command: SlashCommand) => {
    if (command.label === "Drawing" || command.label === "Add Drawing") {
      handleAddDrawing()
      return
    }
    
    if (textareaRef.current) {
      const textarea = textareaRef.current
      const start = textarea.selectionStart || 0
      const end = textarea.selectionEnd || 0
      
      let insertText = ""
      let cursorOffset = 0
      
      switch (command.label) {
        case "Heading 1":
          insertText = "# "
          cursorOffset = 2
          break
        case "Heading 2":
          insertText = "## "
          cursorOffset = 3
          break
        case "Heading 3":
          insertText = "### "
          cursorOffset = 4
          break
        case "Bold":
          insertText = "**bold text**"
          cursorOffset = 2 // Position cursor after first **
          break
        case "Italic":
          insertText = "*italic text*"
          cursorOffset = 1 // Position cursor after first *
          break
        case "Code":
          insertText = "`code`"
          cursorOffset = 1 // Position cursor after first `
          break
        case "Bullet List":
          insertText = "- "
          cursorOffset = 2
          break
        case "Numbered List":
          insertText = "1. "
          cursorOffset = 3
          break
        case "Blockquote":
          insertText = "> "
          cursorOffset = 2
          break
        case "Task List":
          insertText = "- [ ] "
          cursorOffset = 6
          break
        default:
          insertText = command.insert || ""
          cursorOffset = insertText.length
          break
      }
      
      const newTextContent = 
        textContent.substring(0, start) + 
        insertText + 
        textContent.substring(end)
      
      // Update content
      let fullContent = newTextContent
      if (drawings.length > 0) {
        drawings.forEach((drawing) => {
          fullContent += `\n\n\`\`\`drawing\n${drawing}\n\`\`\``
        })
      }
      
      onContentChange({
        target: { value: fullContent }
      })
      
      // Set cursor position after update
      setTimeout(() => {
        const newPosition = start + cursorOffset
        textarea.setSelectionRange(newPosition, newPosition)
        textarea.focus()
      }, 0)
    }
    
    onCommandSelect(command)
  }

  // Drawing handlers
  const handleAddDrawing = () => {
    setEditingDrawingIndex(null)
    setShowDrawingModal(true)
  }

  const handleEditDrawing = (index: number) => {
    setEditingDrawingIndex(index)
    setShowDrawingModal(true)
  }

  const handleDeleteDrawing = (index: number) => {
    const updatedDrawings = drawings.filter((_, i) => i !== index)
    
    // Reconstruct content
    let fullContent = textContent
    if (updatedDrawings.length > 0) {
      updatedDrawings.forEach((drawing) => {
        fullContent += `\n\n\`\`\`drawing\n${drawing}\n\`\`\``
      })
    }
    
    onContentChange({
      target: { value: fullContent }
    })
    
    setShowDrawingModal(false)
    setEditingDrawingIndex(null)
  }

  // Complete handleSaveDrawing function
  const handleSaveDrawing = (drawingData: string) => {
    let updatedDrawings = [...drawings]
    
    if (editingDrawingIndex !== null) {
      // Editing existing drawing
      const oldData = drawings[editingDrawingIndex]
      updatedDrawings[editingDrawingIndex] = drawingData
      
      // Call optional callback for drawing update
      if (onDrawingUpdate) {
        onDrawingUpdate(oldData, drawingData)
      }
    } else {
      // Adding new drawing
      updatedDrawings.push(drawingData)
      
      // Call optional callback for drawing add
      if (onDrawingAdd) {
        onDrawingAdd(drawingData)
      }
    }
    
    // Reconstruct content
    let fullContent = textContent
    if (updatedDrawings.length > 0) {
      updatedDrawings.forEach((drawing) => {
        fullContent += `\n\n\`\`\`drawing\n${drawing}\n\`\`\``
      })
    }
    
    onContentChange({
      target: { value: fullContent }
    })
    
    // Close modal and reset state
    setShowDrawingModal(false)
    setEditingDrawingIndex(null)
  }

  // Enhanced preview with fixed markdown parser
  const enhancedPreviewContent = useMemo(() => {
    if (!textContent) return null
    
    try {
      const parsed = parseMarkdown(textContent)
      return parsed.trim() || null
    } catch (error) {
      console.error('Markdown parsing error:', error)
      // Fallback to simple text with line breaks
      return textContent.replace(/\n/g, '<br>').trim()
    }
  }, [textContent])

  // Enhanced keyboard handling
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Handle slash menu navigation
    if (showSlashMenu) {
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        // Navigation handled by parent
        return
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault()
        return
      }
      if (e.key === 'Enter') {
        e.preventDefault()
        if (slashCommands[selectedCommandIndex]) {
          handleSlashCommandSelect(slashCommands[selectedCommandIndex])
        }
        return
      }
      if (e.key === 'Escape') {
        e.preventDefault()
        return
      }
    }
    
    // Handle Tab for indentation
    if (e.key === 'Tab') {
      e.preventDefault()
      const textarea = e.target as HTMLTextAreaElement
      const start = textarea.selectionStart
      const end = textarea.selectionEnd
      const value = textarea.value
      
      // Insert two spaces for indentation
      const newValue = value.substring(0, start) + '  ' + value.substring(end)
      
      // Create synthetic event
      const changeEvent = {
        target: { value: newValue }
      } as React.ChangeEvent<HTMLTextAreaElement>
      handleTextContentChange(changeEvent)
      
      // Set cursor position after spaces
      setTimeout(() => {
        textarea.setSelectionRange(start + 2, start + 2)
      }, 0)
    }
    
    // Handle Enter for list continuation
    if (e.key === 'Enter') {
      const textarea = e.target as HTMLTextAreaElement
      const start = textarea.selectionStart
      const value = textarea.value
      const beforeCursor = value.substring(0, start)
      const currentLine = beforeCursor.split('\n').pop() || ''
      
      // Check for list patterns
      const bulletMatch = currentLine.match(/^(\s*)- (.*)$/)
      const numberedMatch = currentLine.match(/^(\s*)(\d+)\. (.*)$/)
      const taskMatch = currentLine.match(/^(\s*)- \[([ x])\] (.*)$/)
      
      if (bulletMatch && bulletMatch[2].trim()) {
        e.preventDefault()
        const indent = bulletMatch[1]
        const newValue = value.substring(0, start) + '\n' + indent + '- ' + value.substring(start)
        handleTextContentChange({ target: { value: newValue } } as React.ChangeEvent<HTMLTextAreaElement>)
        setTimeout(() => {
          textarea.setSelectionRange(start + indent.length + 3, start + indent.length + 3)
        }, 0)
      } else if (numberedMatch && numberedMatch[3].trim()) {
        e.preventDefault()
        const indent = numberedMatch[1]
        const nextNum = parseInt(numberedMatch[2]) + 1
        const newValue = value.substring(0, start) + '\n' + indent + nextNum + '. ' + value.substring(start)
        handleTextContentChange({ target: { value: newValue } } as React.ChangeEvent<HTMLTextAreaElement>)
        setTimeout(() => {
          const newPos = start + indent.length + nextNum.toString().length + 3
          textarea.setSelectionRange(newPos, newPos)
        }, 0)
      } else if (taskMatch && taskMatch[3].trim()) {
        e.preventDefault()
        const indent = taskMatch[1]
        const newValue = value.substring(0, start) + '\n' + indent + '- [ ] ' + value.substring(start)
        handleTextContentChange({ target: { value: newValue } } as React.ChangeEvent<HTMLTextAreaElement>)
        setTimeout(() => {
          textarea.setSelectionRange(start + indent.length + 6, start + indent.length + 6)
        }, 0)
      }
    }
  }

  if (!isOpen) return null

  return (
    <>
      <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div 
          className="bg-white/95 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl p-10 w-full max-w-6xl max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-medium text-slate-800">
              {editingNote ? "Edit Note" : "New Note"}
            </h2>
            <Button onClick={onClose} variant="ghost" size="sm">
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="space-y-8">
            <Input
              type="text"
              placeholder="Note title..."
              value={newNote.title}
              onChange={(e) => onTitleChange(e.target.value)}
              className="text-2xl font-medium bg-transparent border-0 border-b border-slate-200 rounded-none px-0 py-4 focus:border-orange-400"
            />

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
              {/* Writing Section */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-slate-700">Write</h3>
                  <Button
                    onClick={handleAddDrawing}
                    variant="ghost"
                    size="sm"
                    className="text-slate-500 hover:text-orange-600 flex items-center gap-2"
                  >
                    <PenTool className="w-4 h-4" />
                    Add Drawing
                  </Button>
                </div>
                
                <div className="relative">
                  <Textarea
                    ref={textareaRef}
                    placeholder="Start writing your thoughts... (Type / for formatting options)"
                    value={textContent}
                    onChange={handleTextContentChange}
                    onKeyDown={handleKeyDown}
                    className="h-[300px] max-h-[300px] bg-transparent border border-slate-200 rounded-2xl resize-none text-lg leading-relaxed p-6 text-slate-700 placeholder:text-slate-400 focus:border-orange-400 font-mono"
                    style={{ fontFamily: 'ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", Menlo, monospace' }}
                  />

                  <SlashMenu
                    isVisible={showSlashMenu}
                    commands={slashCommands}
                    selectedIndex={selectedCommandIndex}
                    onCommandSelect={handleSlashCommandSelect}
                  />
                </div>

                {/* Drawings Section */}
                {drawings.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="text-md font-medium text-slate-700 flex items-center gap-2">
                      <PenTool className="w-4 h-4" />
                      Drawings ({drawings.length})
                    </h4>
                    <div className="space-y-3">
                      {drawings.map((drawing, index) => (
                        <div
                          key={index}
                          className="group relative bg-slate-50/80 border border-slate-200 rounded-2xl p-4"
                        >
                          <DrawingViewer
                            drawingData={drawing}
                            onEdit={() => handleEditDrawing(index)}
                            onDelete={() => handleDeleteDrawing(index)}
                            isPreview={true}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Preview Section */}
              <div className="relative hidden xl:block">
                <h3 className="text-lg font-medium text-slate-700 mb-4">Preview</h3>
                <div className="min-h-[400px] max-h-[600px] overflow-y-auto border border-slate-200 rounded-2xl p-6 bg-slate-50/30">
                  {newNote.title && (
                    <h1 className="text-2xl font-bold text-slate-800 mb-6">{newNote.title}</h1>
                  )}
                  
                  {enhancedPreviewContent && (
                    <div
                      className="text-slate-700 leading-relaxed mb-6"
                      dangerouslySetInnerHTML={{ __html: enhancedPreviewContent }}
                    />
                  )}
                  
                  {drawings.map((drawing, index) => (
                    <div key={index} className="my-6">
                      <DrawingViewer
                        drawingData={drawing}
                        onEdit={() => handleEditDrawing(index)}
                        isPreview={false}
                      />
                    </div>
                  ))}
                  
                  {(!enhancedPreviewContent && drawings.length === 0) && (
                    <p className="text-slate-400 italic">Start writing to see preview...</p>
                  )}
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4 pt-6">
              <Button
                onClick={onClose}
                variant="ghost"
                className="text-slate-500 hover:text-orange-700 px-6 py-3"
              >
                Cancel
              </Button>
              <Button
                onClick={onSave}
                disabled={isDisabled}
                className="bg-orange-600 hover:bg-orange-700 text-white rounded-2xl px-8 py-3 disabled:opacity-50"
              >
                {editingNote ? "Update Note" : "Save Note"}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <ExcalidrawModal
        isOpen={showDrawingModal}
        onClose={() => {
          setShowDrawingModal(false)
          setEditingDrawingIndex(null)
        }}
        onSave={handleSaveDrawing}
        initialData={
          editingDrawingIndex !== null && drawings[editingDrawingIndex]
            ? drawings[editingDrawingIndex]
            : undefined
        }
      />
    </>
  )
})

ImprovedNoteEditor.displayName = "ImprovedNoteEditor"

export default ImprovedNoteEditor